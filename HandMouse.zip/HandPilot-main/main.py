import cv2
import mediapipe as mp
import pyautogui
import numpy as np
from tkinter import Tk, Label, Button, Scale, HORIZONTAL, IntVar

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(min_detection_confidence=0.7, min_tracking_confidence=0.7)
mp_draw = mp.solutions.drawing_utils

screen_width, screen_height = pyautogui.size()

virtual_screen_width = screen_width + 400
virtual_screen_height = screen_height + 400

smoothing_factor = 5

def smooth_coordinates(new_point, prev_point):
    if prev_point is None:
        return new_point
    return [
        int(prev_point[0] + (new_point[0] - prev_point[0]) / smoothing_factor),
        int(prev_point[1] + (new_point[1] - prev_point[1]) / smoothing_factor),
    ]

root = Tk()
root.title("Cursor Control Settings")

sensitivity_var = IntVar(value=10)

Label(root, text="Sensitivity").pack()
Scale(root, from_=1, to=20, orient=HORIZONTAL, variable=sensitivity_var).pack()

Label(root, text="Press 'q' in the video feed to quit.").pack()
Button(root, text="Start", command=root.destroy).pack()

root.mainloop()

cap = cv2.VideoCapture(0)
prev_coords = None

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    frame_height, frame_width, _ = frame.shape

    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(rgb_frame)

    if result.multi_hand_landmarks:
        for hand_landmarks, hand_info in zip(result.multi_hand_landmarks, result.multi_handedness):
            # Extract handedness (left or right)
            handedness = hand_info.classification[0].label

            # Extract index finger tip coordinates for the right hand (cursor control)
            index_finger_tip = hand_landmarks.landmark[8]
            x = int(index_finger_tip.x * frame_width)
            y = int(index_finger_tip.y * frame_height)

            # If it's the right hand, move the cursor
            if handedness == "Right":
                # Map coordinates to the larger virtual screen area
                screen_x = np.interp(x, [0, frame_width], [0, virtual_screen_width])
                screen_y = np.interp(y, [0, frame_height], [0, virtual_screen_height])

                # Smooth movement
                smoothed_coords = smooth_coordinates([screen_x, screen_y], prev_coords)
                prev_coords = smoothed_coords

                # Move the cursor within the virtual screen area
                pyautogui.moveTo(smoothed_coords[0], smoothed_coords[1], duration=0.01)

                # Draw landmarks
                mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                # Highlight index finger tip
                cv2.circle(frame, (x, y), 10, (0, 255, 0), cv2.FILLED)

            # If it's the left hand, trigger a click
            if handedness == "Left":
                # Left hand detected, trigger click
                pyautogui.click()

                # Draw landmarks and highlight the left index finger tip for feedback
                mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                cv2.circle(frame, (x, y), 10, (0, 0, 255), cv2.FILLED)  # Red circle for left index tip

    # Display the frame
    cv2.imshow("Hand Tracking", frame)

    # Break the loop when 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
